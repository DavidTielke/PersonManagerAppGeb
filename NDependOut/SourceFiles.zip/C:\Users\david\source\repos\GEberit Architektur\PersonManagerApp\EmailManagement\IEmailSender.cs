﻿namespace DavidTielke.PMA.Logic.Integration.EmailManagement;

public interface IEmailSender
{
    void Send(string text);
}