﻿namespace DavidTielke.PMA.Data.FileStorage;

public interface IFileReader
{
    IEnumerable<string> ReadAllLines(string path);
}