﻿namespace DavidTielke.PMA.UI.ConsoleClient;

public interface IPersonDisplayCommands
{
    void DisplayAllAdults();
    void AddNewPerson();
    void DisplayAllChildren();
}