﻿namespace DavidTielke.PMA.Logic.Integration.OutlookManagement;

public interface IOutlookContactManager
{
    void Add();
}