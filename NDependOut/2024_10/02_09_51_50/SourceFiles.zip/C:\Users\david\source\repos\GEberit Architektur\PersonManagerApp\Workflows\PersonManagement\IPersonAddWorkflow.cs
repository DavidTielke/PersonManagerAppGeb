﻿using DavidTielke.PMA.CrossCutting.DataClasses;

namespace DavidTielke.PMA.Logic.Business.Workflows.PersonManagement;

public interface IPersonAddWorkflow
{
    void Run(Person person);
}